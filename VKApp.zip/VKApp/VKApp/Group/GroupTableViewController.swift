//
//  GroupTableViewController.swift
//  VKApp
//
//  Created by Елизавета Пенар on 14.10.2020.
//

import UIKit

class GroupTableViewController: UITableViewController {
    
//    let groups: [Groups] = [Groups(avatar: "5", name: "Gamers"), Groups(avatar: "6", name: "Travellers"), Groups(avatar: "7", name: "Romatics"), Groups(avatar: "8", name: "Singles")]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Groups"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
    // #warning Incomplete implementation, return the number of sections
    return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let item = GroupsDataBase.instance.item.filter{ (i) -> Bool in
            return i.added == true
        }
        return item.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "groupCell") as! GroupTableViewCell
        let item = GroupsDataBase.instance.item.filter{ (i) -> Bool in
            return i.added == true
        }
        
        
        cell.avatarImageView.image = UIImage(named: item[indexPath.row].avatar)
        cell.titleLabel.text = item[indexPath.row].title
        
        return cell
    }
    
//    функции для смаха ячейки влево и ее удаления
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            // handle delete (by removing the data from your array and updating the tableview)
        }
    }
}
