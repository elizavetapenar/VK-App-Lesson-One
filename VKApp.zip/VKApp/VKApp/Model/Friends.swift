//
//  Friends.swift
//  VKApp
//
//  Created by Елизавета Пенар on 14.10.2020.
//

import Foundation
import UIKit

struct Friends {
    var avatar: String
    var name: String
}
