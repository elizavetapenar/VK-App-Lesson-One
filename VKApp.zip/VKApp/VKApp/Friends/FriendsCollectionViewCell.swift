//
//  FriendsCollectionViewCell.swift
//  VKApp
//
//  Created by Елизавета Пенар on 14.10.2020.
//

import UIKit

class FriendsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var avatarImageView: UIImageView!
}
