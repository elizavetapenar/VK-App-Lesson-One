//
//  FriendsTableViewController.swift
//  VKApp
//
//  Created by Елизавета Пенар on 06.10.2020.
//

import UIKit

class FriendsTableViewController: UITableViewController {
    
    let friends: [Friends] = [Friends(avatar: "1", name: "Barsik"), Friends(avatar: "2", name: "Musya"), Friends(avatar: "3", name: "Sofa"), Friends(avatar: "4", name: "Bulka")]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Friends"
        
//        tableView.register(UINib(nibName: "UniversalTableViewCell", bundle: nil), forCellReuseIdentifier: "universalCell")
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
    // #warning Incomplete implementation, return the number of sections
    return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friends.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "friendCell") as! FriendTableViewCell
        
        cell.avatarImageView.image = UIImage(named: friends[indexPath.row].avatar)
        cell.nameLabel.text = friends[indexPath.row].name
        
        return cell
    }
}
