//
//  SearchTableViewController.swift
//  VKApp
//
//  Created by Елизавета Пенар on 15.10.2020.
//

import UIKit

class SearchTableViewController: UITableViewController {
    
    var item = GroupsDataBase.instance.item.filter{ (i) -> Bool in
        return i.added == false
    }
    
//    let newGroups: [Groups] = [Groups(avatar: "9", name: "Music"), Groups(avatar: "10", name: "Books"), Groups(avatar: "11", name: "Podcasts"), Groups(avatar: "12", name: "Photos")]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Search"
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
    // #warning Incomplete implementation, return the number of sections
    return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchCell") as! SearchTableViewCell
        
        cell.avatarImageView.image = UIImage(named: item[indexPath.row].avatar)
        cell.titleLabel.text = item[indexPath.row].title
        
        return cell
        }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        item[indexPath.row].added = true
//        вызов функции добавления групп
        GroupsDataBase.instance.change(groups: item[indexPath.row])
            
        self.navigationController?.popViewController(animated: true)
    }
}
