//
//  MyTableViewCell.swift
//  VKApp
//
//  Created by Елизавета Пенар on 06.10.2020.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet var NameLabel: UILabel?
    
    
    @IBOutlet var ImageLabel: UIImageView?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
