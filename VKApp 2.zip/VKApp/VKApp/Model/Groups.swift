//
//  Groups.swift
//  VKApp
//
//  Created by Елизавета Пенар on 14.10.2020.
//

import Foundation

struct Groups {
    var avatar: String
    var title: String
    var added: Bool
}

class GroupsDataBase {
    
    static let instance = GroupsDataBase()
    private init() {    }
    
    var item: [Groups] = [
    Groups(avatar: "5", title: "Gamers", added: false),
    Groups(avatar: "6", title: "Travellers", added: false),
    Groups(avatar: "7", title: "Romantics", added: false),
    Groups(avatar: "8", title: "Singels", added: false),
    Groups(avatar: "9", title: "Music", added: false),
    Groups(avatar: "10", title: "Books", added: false),
    Groups(avatar: "11", title: "Podcasts",added: false),
    Groups(avatar: "12", title: "Photos",added: false)
    ]
    
//    добавление новых групп во вкладку группы
    func change(groups: Groups){
        for i in 0..<item.count {
            if item[i].title == groups.title {
                item[i] = groups
            }
        }
    }
}
