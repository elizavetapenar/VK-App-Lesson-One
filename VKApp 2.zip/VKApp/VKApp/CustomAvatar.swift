//
//  CustomAvatar.swift
//  VKApp
//
//  Created by Елизавета Пенар on 19.10.2020.
//

import Foundation
import UIKit

@IBDesignable class CustomAvatar: UIView {
    
    @IBInspectable var size: CGFloat = 8 {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var color: UIColor = UIColor.black{
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var opacity: Float = 0.8{
        didSet {
            setNeedsDisplay()
        }
    }
    
    var imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    
    override func draw(_ rect: CGRect) {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        view.layer.cornerRadius = size
            
        view.layer.shadowColor = color.cgColor
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 8
        view.layer.shadowOpacity = opacity
        
        self.addSubview(view)
        self.addSubview(imageView)
        
        
    }
}
